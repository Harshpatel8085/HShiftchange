export const QUERY_PARAM_AREA_ID = 'areaId';
export const GET_ALL_REPORTS_PATH = 'https://jsoneditoronline.herokuapp.com/v1/docs/df327c9caef24189af4e09dd8e9ade24'
export const GET_ALL_USERS_PATH = 'https://jsoneditoronline.herokuapp.com/v1/docs/d9208d4db12f43f3b5bdec30749fdb47'
//export const GET_ALL_REPORTS_PATH = 'http://localhost:53878/api/shiftreport/GetAllReports';