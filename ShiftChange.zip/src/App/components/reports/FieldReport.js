import React from "react";
import {
    Row,
    Col,
    Card,
    Form,
    Button,
    InputGroup,
    Table,
    FormControl
} from "react-bootstrap";

import Aux from "../../../hoc/_Aux";
import getCurrentDate from "../../helper";
import API from "../../../api";
import YesNoInput from "./YesNoFormInput";
import YesTextInput from "./YesTextInput";

class FieldReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }


    // * Render form
    render() {
        return (
            <Row>
                <Col>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Header>
                                    <Card.Title as="h5">
                                        Field Report
                                </Card.Title>
                                </Card.Header>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5"> </Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <YesNoInput  {...this.props} handleChange={this.props.handleChange}
                                    label="Abnormal Operations" id="FR_AbnormalOperations" reportType="FR" /> 
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5">Operation Problems</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesNoInput  {...this.props} handleChange={this.props.handleChange} label="Operation Problems" id="Operations_Problems" reportType="FR_OperationsProblems" />
                                            <YesNoInput  {...this.props} handleChange={this.props.handleChange} label="Conditions" id="Conditions" reportType="FR_OperationsProblems" />
                                            <YesNoInput  {...this.props} handleChange={this.props.handleChange} label="Counter Measures" id="Counter_Measures" reportType="FR_OperationsProblems" />
                                            <YesNoInput  {...this.props} handleChange={this.props.handleChange} label="Notifications" id="Notifications" reportType="FR_OperationsProblems" />
                                        </Col>
                                    </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5">Bypasses Opened</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <Row>
                                    <Col sm={12}>
                                        <YesNoInput  {...this.props} handleChange={this.props.handleChange}  id="Bypasses_Opened" label="Bypasses Opened" reportType="FR_Bypasses_Opened" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Equipment_Number" label="BEquipment Number (What was bypassed)" reportType="FR_Bypasses_Opened" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Bypass_Opened" label="How much is the bypass opened?" reportType="FR_Bypasses_Opened" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Comments" label="Comments" reportType="FR_Bypasses_Opened" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Reason_passed" label="Reason" reportType="FR_Bypasses_Opened" />
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Card>
                        <Card.Header>
                                <Card.Title as="h5">Dual Pump Running</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <Row>
                                    <Col sm={12}>
                                        {/* <YesTextInput id="Dual_Pump_Running" label="Dual Pumps Running" reportType="FR_Dual_Pumps_Running" /> */}
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Equipment" label="Equipment" reportType="FR_Dual_Pumps_Running" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Process_Affected" label="Process Affected" reportType="FR_Dual_Pumps_Running" />
                                        <YesNoInput  {...this.props} handleChange={this.props.handleChange}  id="Mitigation_Plan" label="Mitigation Plan" reportType="FR_Dual_Pumps_Running" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="WO#" label="WO#" reportType="FR_Dual_Pumps_Running" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Estimated_Return_to_Service" label="Estimated Return to Service" reportType="FR_Dual_Pumps_Running" />
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Maintenance_Status" label="Maintenance Status" reportType="FR_Dual_Pumps_Running" />
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5">Equipment Maintenance</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <Row>
                                    <Col sm={12}>
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Equipment_Maintenance" label="Maintenance" reportType="FR_EquipmentMaintenance" />
                                        {/* <YesNoInput label="Equipment Ready for Maintenance"  reportType="FR_EquipmentMaintenance" /> */}
                                        <YesTextInput  {...this.props} handleChange={this.props.handleChange}  id="Operation_Hours" label="Operations Hours" reportType="FR_EquipmentMaintenance" />
                                        <YesNoInput  {...this.props} handleChange={this.props.handleChange} id="LOTO"  label="LOTO" reportType="FR_EquipmentMaintenance" />
                                        {/* <YesTextInput label="Comments"  reportType="FR_EquipmentMaintenance" />
                                    <YesTextInput label="Maintenance Status"  reportType="FR_EquipmentMaintenance" /> */}
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                {/* <Row>
                    <Col>
                        <Card>
                            <Card.Body>
                                <YesNoInput label="Special Meetings (? For Brad Rose Unit Message Board?)"  reportType="FR" />
                                <YesTextInput label="Additional Comments"  reportType="FR" />
                            </Card.Body>
                        </Card>
                    </Col>
                </Row> */}
                    {/* <Row>
                    <Col>
                        <Card>
                            <Card.Body>
                                <Button type="submit">Submit</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row> */}
                </Col>
            </Row>
        );
    }
}

export default FieldReport;
