import React from "react";
import {
  Row,
  Col,
  Card,
  Form,
  Button,
  InputGroup,
  Table,
  Toast,
  Alert
} from "react-bootstrap";

import Aux from "../../../hoc/_Aux";
import getCurrentDate from "../../helper";
import API from "../../../api";
import ProductionSupervisorReport from "./ProductionSupervisorReport";
import AreaSupervisorReport from "./AreaSupervisorReport";
import AreaAReport from "./AreaAReport";
import ConsoleReport from "./ConsoleReport";
import FieldReport from "./FieldReport";
import { getQueryParamValue } from "../../util/Util";
import { QUERY_PARAM_AREA_ID } from "../../constants/AppConstants";
import { JSON_LIST_OF_OPERATING_TARGETS, FORM_STATUS_NEW, FORM_STATUS_SUCCESS, FORM_STATUS_ERROR } from "./Constants";

class AllReportsForm extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      areaId: parseInt(getQueryParamValue(props, QUERY_PARAM_AREA_ID), 10),
      formStatus: FORM_STATUS_NEW,
    };
  }
// * Handle button click
  handleChange = (event) => {
    console.log(event.target.id +":" + event.target.value);
    this.setState({ [event.target.id]: event.target.value });
  };

  getPSRRequest = () => {
    const pSRRequest = {};
    const type = "PSR";
    pSRRequest["RoadClosures"] = this.state[`${type}_RoadClosures`];
    pSRRequest["FirstMaintainStart"] = this.state[`${type}_FirstMaintainStart`];
    pSRRequest["PSR_AbnormalOperations"] = this.state[`${type}_PSR_AbnormalOperations`];
    pSRRequest["FeedstockChanges"] = this.state[`${type}_FeedstockChanges`];
    pSRRequest["LineupChanges"] = this.state[`${type}_LineupChanges`];
    pSRRequest["PSR_OperationsProblems"] = [
      {
        "Conditions": this.state[`${type}_Conditions`],
        "CounterMeasures": this.state[`${type}_CounterMeasures`],
        "Notifications": this.state[`${type}_Notifications`]
      }
    ];

    let PSR_OperatingTargets = this.getOperatingTargets().map(operatingTarget => {
      return {
        ...operatingTarget,
        Area_ID: this.state.areaId,

      }
    })
    //pSRRequest["PSR_OperatingTargets"] = PSR_OperatingTargets;
    let PSR_OperatingConstraints = this.getOperatingTargets().map(operatingTarget => {
      return {
        ...operatingTarget,
        "Reason": this.state[`${type}_Reason_${operatingTarget.OT_ID}`],
        "Remediation": this.state[`${type}_Remediation_${operatingTarget.OT_ID}`],
        "Date": this.state[`${type}_Date_${operatingTarget.OT_ID}`],

        Area_ID: this.state.areaId,

      }
    })
    //pSRRequest["PSR_OperatingConstraints"] = PSR_OperatingConstraints;
    return pSRRequest;
  }

  getASRRequest = () =>{
    const pSRRequest = {};
    const type = "ASR";
    pSRRequest["SafetyMeetings"] = this.state[`${type}_SafetyMeetings`];
    pSRRequest["ASR_Environmental"] = [
      {
        "Incidents": this.state[`${type}_Incidents`],
        "NearMisses": this.state[`${type}_NearMisses`],
        "DrainingofEquipment": this.state[`${type}_DrainingofEquipment`],
        "Venting": this.state[`${type}_Venting`],
        "Venting_Flare": this.state[`${type}_Venting_Flare`],
        "Venting_Atmosphere": this.state[`${type}_Venting_Atmosphere`],
        "Deviations": this.state[`${type}_Deviations`],
        "SpecialMonitoring": this.state[`${type}_SpecialMonitoring`]
      }
    ];
    pSRRequest["ASR_MOC"] = [
      {
        "Number": this.state[`${type}_Number`],
        "Title": this.state[`${type}_Title`],
        "Status": this.state[`${type}_Status`],
        "Authorize": this.state[`${type}_Authorize`],
        "Training": this.state[`${type}_Training`],
      }
    ]
    return pSRRequest;
  }

  getCRRequest = () =>{
    const pSRRequest = {};
    const type = "CR";
    pSRRequest["CR_AbnormalOperations"] = this.state[`${type}_CR_AbnormalOperations`];
    pSRRequest["CR_OperationsProblems"] = [
      {
        "Operations_Problems": this.state[`${type}_Operations_Problems`],
        "Conditions": this.state[`${type}_Conditions`],
        "Counter_Measures": this.state[`${type}_Counter_Measures`],
        "Notifications": this.state[`${type}_Notifications`],
      }
    ]
    pSRRequest["CR_ProcessControls"] = [
      {
        "Alarms": this.state[`${type}_Alarms`],
        "Controllability": this.state[`${type}_Controllability`],
        "Loops_in_Control": this.state[`${type}_Loops_in_Control`],
        "Loops_on_high_mode": this.state[`${type}_Loops_on_high_mode`],
      }
    ]
    return pSRRequest;
  }

  getARRequest = () =>{
    const pSRRequest = {};

    pSRRequest["AR_SafetyAndHealth"] = [
      {
        "Incidents": this.state[`AR_SafetyAndHealth_Incidents`],
        "NearMisses": this.state[`AR_SafetyAndHealth_NearMisses`],
        "LMRA_s": this.state[`AR_SafetyAndHealth_LMRA_s`],
        "SOP_Deviations": this.state[`AR_SafetyAndHealth_SOP_Deviations`],
        "ScheduleHighRiskJobs": this.state[`AR_SafetyAndHealth_ScheduleHighRiskJobs`]
      }
    ]
    pSRRequest["AR_SH_COD"] = [
      {
        "COD/SCD": this.state[`AR_SH_COD_COD/SCD`],
        "Device": this.state[`AR_SH_COD_Device`],
        "ActiveorClosed": this.state[`AR_SH_COD_ActiveorClosed`],
        "SystemBeingProtected": this.state[`AR_SH_COD_SystemBeingProtected`],
        "MitigationPlan": this.state[`AR_SH_COD_MitigationPlan`],
        "Status": this.state[`AR_SH_COD_Status`],
        "WO#": this.state[`AR_SH_COD_WO#`],
      }
    ]
    pSRRequest["AR_Reliability"] = [
      {
        "Process_Consequence_Analysis": this.state[`AR_Reliability_Process_Consequence_Analysis`],
        "Reliability_Parameter_Deviations": this.state[`AR_Reliability_Reliability_Parameter_Deviations`],
        "Equipment_Out_Of_Service": this.state[`AR_Reliability_Equipment_Out_Of_Service`],
        "Equipment_Returned_to_Service": this.state[`AR_Reliability_Equipment_Returned_to_Service`],
        "Critical_Instrumentation_Failure": this.state[`AR_Reliability_Critical_Instrumentation_Failure`],
        "Total_Equipment_Failure": this.state[`AR_Reliability_Total_Equipment_Failure`],
        "Total_Single_Point_of_Failure": this.state[`AR_Reliability_Total_Single_Point_of_Failure`],
        "Maintainence_Scheduled_or_InProgress": this.state[`AR_Reliability_Maintainence_Scheduled_or_InProgress`],
        "Active_Permits": this.state[`AR_Reliability_Active_Permits`],
        "Issues": this.state[`AR_Reliability_Issues`],
        "Inventory_Tank_Levels": this.state[`AR_Reliability_Inventory_Tank_Levels`]
      }
    ]
    pSRRequest["AR_RE_InstrumentationOutofService"] = [
      {
        "Instrumentation_Out_of_Service": this.state[`AR_RE_InstrumentationOutofService_Instrumentation_Out_of_Service`],
        "Equipment": this.state[`AR_RE_InstrumentationOutofService_Equipment`],
        "Process_Affected": this.state[`AR_RE_InstrumentationOutofService_Process_Affected`],
        "PCA_Created": this.state[`AR_RE_InstrumentationOutofService_PCA_Created`],
        "Maintenance_Status": this.state[`AR_RE_InstrumentationOutofService_Maintenance_Status`],
        "WO#": this.state[`AR_RE_InstrumentationOutofService_WO#`],
        "Estimated_Return_to_Service": this.state[`AR_RE_InstrumentationOutofService_Estimated_Return_to_Service`]
      }
    ]
    pSRRequest["AR_RE_EqpReturnedtoOperations"] = [
      {
        "Equipment_Returned_to_Operations": this.state[`AR_RE_EqpReturnedtoOperations_Equipment_Returned_to_Operations`],
        "Equipment": this.state[`AR_RE_EqpReturnedtoOperations_Equipment`],
        "Placed_In_Service": this.state[`AR_RE_EqpReturnedtoOperations_Placed_In_Service`],
        "WO#": this.state[`AR_RE_EqpReturnedtoOperations_WO#`]
      }
    ]
    pSRRequest["AR_RE_SinglePointOfFailure"] = [
      {
        "Single_Point_of_Failure": this.state[`AR_RE_SinglePointOfFailure_Single_Point_of_Failure`],
        "Equipment": this.state[`AR_RE_SinglePointOfFailure_Equipment`],
        "Process_Affected": this.state[`AR_RE_SinglePointOfFailure_Process_Affected`],
        "Mitigation_Plan": this.state[`AR_RE_SinglePointOfFailure_Mitigation_Plan`],
        "WO#": this.state[`AR_RE_SinglePointOfFailure_WO#`],
        "Estimated_Return_to_Service": this.state[`AR_RE_SinglePointOfFailure_Estimated_Return_to_Service`],
        "Maintenance_Status": this.state[`AR_RE_SinglePointOfFailure_Maintenance_Status`],
        "Comments": this.state[`AR_RE_SinglePointOfFailure_Comments`]
      }
    ]
    pSRRequest["AR_RE_Streams"] = [
      {
        "Off_Speciation": this.state[`AR_RE_Streams_Off_Speciation`],
        "In_Slop": this.state[`AR_RE_Streams_In_Slop`],
        "Finished_Product_Off_Speciation": this.state[`AR_RE_Streams_Finished_Product_Off_Speciation`]
      }
    ]
    pSRRequest["AR_RE_Deliveries"] = [
      {
        "Chemical_Loaded": this.state[`AR_RE_Deliveries_Chemical_Loaded`],
        "Chemical_Off-Loaded": this.state[`AR_RE_Deliveries_Chemical_Off-Loaded`],
        "Inventories_Loaded": this.state[`AR_RE_Deliveries_Inventories_Loaded`],
        "Inventories_Off-Loaded": this.state[`AR_RE_Deliveries_Inventories_Off-Loaded`]
      }
    ]
    return pSRRequest;
  }

  getFRRequest = () =>{
    const pSRRequest = {};
    const type = "FR";
    pSRRequest["FR_AbnormalOperations"] = this.state[`${type}_FR_AbnormalOperations`];
    pSRRequest["FR_OperationsProblems"] = [
      {
        "Operations_Problems": this.state[`FR_OperationsProblems_Operations_Problems`],
        "Conditions": this.state[`FR_OperationsProblems_Conditions`],
        "Counter_Measures": this.state[`FR_OperationsProblems_Counter_Measures`],
        "Notifications": this.state[`FR_OperationsProblems_Notifications`]
      }
    ]
    pSRRequest["FR_Bypasses_Opened"] = [
      {
        "Bypasses_Opened": this.state[`FR_Bypasses_Opened_Bypasses_Opened`],
        "Equipment_Number": this.state[`FR_Bypasses_Opened_Equipment_Number`],
        "Bypass_Opened": this.state[`FR_Bypasses_Opened_Bypass_Opened`],
        "Comments": this.state[`FR_Bypasses_Opened_Comments`],
        "Reason_passed": this.state[`FR_Bypasses_Opened_Reason_passed`]
      }
    ]
    pSRRequest["FR_Dual_Pumps_Running"] = [
      {
        // "Dual_Pump_Running": this.state[`FR_Dual_Pumps_Running_Dual_Pump_Running`],
        "Equipment": this.state[`FR_Dual_Pumps_Running_Equipment`],
        "Process_Affected": this.state[`FR_Dual_Pumps_Running_Process_Affected`],
        "Mitigation_Plan": this.state[`FR_Dual_Pumps_Running_Mitigation_Plan`],
        "WO#": this.state[`FR_Dual_Pumps_Running_WO#`],
        "Estimated_Return_to_Service": this.state[`FR_Dual_Pumps_Running_Estimated_Return_to_Service`],
        "Maintenance_Status": this.state[`FR_Dual_Pumps_Running_Maintenance_Status`]
      }
    ]
    pSRRequest["FR_EquipmentMaintenance"] = [
      {
        "Dual_Pump_Running": this.state[`FR_EquipmentMaintenance_Equipment_Maintenance`],
        "Equipment": this.state[`FR_EquipmentMaintenance_Operation_Hours`],
        "LOTO": this.state[`FR_EquipmentMaintenance_LOTO`]
      }
    ]
    return pSRRequest;
  }

  // * Submit form to API. POST
  handleSubmit = event => {
    event.preventDefault(); 

    //create request
    let requestObj = {};
    requestObj.Area_ID = this.state.areaId;
    requestObj.Shift = "1";
    requestObj.User_ID = 1;
    requestObj.CreatedBy = "HSimpson";
    requestObj.UpdatedBy = "HSimpson";
    requestObj = {...requestObj, ...this.getPSRRequest()};
    requestObj = {...requestObj, ...this.getASRRequest()};
    requestObj = {...requestObj, ...this.getCRRequest()};
    requestObj = {...requestObj, ...this.getARRequest()};
    requestObj = {...requestObj, ...this.getFRRequest()};
    
    console.info(requestObj);
  

    API.post(
      "http://localhost:53878/api/ShiftReport/AddNewReport",
      {
        ...requestObj
      },
      { headers: { "Content-Type": "application/json" } }
    )
      .then(response => {
        //this.props.history.push("/");
        console.log(response.data);
        let existingState = { ...this.state };
        for (var key in existingState) {
          existingState[key] = "";
        }
        this.setState({ ...existingState, formStatus: FORM_STATUS_SUCCESS });
      })
      .catch(err => {
        console.log(err)
        let existingState = { ...this.state };
        for (var key in existingState) {
          existingState[key] = "";
        }
        this.setState({ formStatus: FORM_STATUS_ERROR });
      });     
  };

  //* Get data from API. GET
  componentDidMount() {
    // API.get("shiftreport/1").then(res => {
    //   const report = res.data;
    //   this.setState({ SafetyTopic: report.SafetyTopic,LMRAs:report.LMRAs });
    //   console.log(report);
    // });
  }

  componentDidUpdate(prevProps, prevState) {
    let prevAreaId = getQueryParamValue(prevProps, QUERY_PARAM_AREA_ID);
    let currentAreaId = getQueryParamValue(this.props, QUERY_PARAM_AREA_ID);
    if (prevAreaId !== currentAreaId) {
      this.setState({ areaId: parseInt(currentAreaId, 10), formStatus: FORM_STATUS_NEW});
    }
  }

  getOperatingTargets = () => {
    console.log("area Id : ", this.props.areaId);
    return JSON_LIST_OF_OPERATING_TARGETS.filter(operatingTarget => operatingTarget.Area_ID === this.state.areaId)
}


    // * Render form
    render() {
      let variant = this.state.formStatus === "SUCCESS" ? "success" :
            (this.state.formStatus === "ERROR" ? "danger" : "");
        let message = this.state.formStatus === "SUCCESS" ? "Form submitted successfully!" :
            (this.state.formStatus === "ERROR" ? "Form submittion failed!" : "");
        return (
            <Form onSubmit={this.handleSubmit}>

            <Aux>
              {this.state.formStatus && this.state.formStatus !== "NEW" && <Row>
                <Col>
                  <Card>
                    <Card.Body>
                      <Alert variant={variant}>
                        {message}
                      </Alert>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>}
              <ProductionSupervisorReport getOperatingTargets={this.getOperatingTargets} areaId={this.state.areaId} handleChange={this.handleChange} />
              <AreaSupervisorReport getOperatingTargets={this.getOperatingTargets} areaId={this.state.areaId} handleChange={this.handleChange} />
              <AreaAReport  getOperatingTargets={this.getOperatingTargets} areaId={this.state.areaId} handleChange={this.handleChange} />
              <ConsoleReport getOperatingTargets={this.getOperatingTargets} areaId={this.state.areaId} handleChange={this.handleChange} />
              <FieldReport  getOperatingTargets={this.getOperatingTargets} areaId={this.state.areaId} handleChange={this.handleChange}/> 
                    <Row>
                        <Col>
                            <Card>
                                <Card.Body>
                                    <Button type="submit">Submit</Button>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </Aux>
            </Form>
        );
    }
}

export default AllReportsForm;