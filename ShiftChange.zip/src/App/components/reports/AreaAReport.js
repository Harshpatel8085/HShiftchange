import React from "react";
import {
    Row,
    Col,
    Card,
    Form,
    Button,
    InputGroup,
    Table,
    FormControl
} from "react-bootstrap";

import Aux from "../../../hoc/_Aux";
import getCurrentDate from "../../helper";
import API from "../../../api";
import YesNoInput from "./YesNoFormInput";
import YesTextInput from "./YesTextInput";

class AreaAReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }


    // * Render form
    render() {
        return (
            <Row>
                <Col>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Header>
                                    <Card.Title as="h5">
                                        Area A Report
                                </Card.Title>
                                </Card.Header>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Safety and Health</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Incidents" id="Incidents" reportType="AR_SafetyAndHealth" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Near Misses" id="NearMisses" reportType="AR_SafetyAndHealth" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="LMRA's" id="LMRA_s" reportType="AR_SafetyAndHealth" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Safe Operating Parameter Deviations" id="SOP_Deviations" reportType="AR_SafetyAndHealth" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Schedule High Rist Job" id="ScheduleHighRiskJobs" reportType="AR_SafetyAndHealth" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row> 
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">COD or Safety Critical Devices</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="COD/SCD" id="COD/SCD" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Device" id="Device" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Active or Closed during shift" id="ActiveorClosed" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="System Being Protected" id="SystemBeingProtected" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Mitigation Plan" id="MitigationPlan" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Status" id="Status" reportType="AR_SH_COD" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="WO#" id="WO#" reportType="AR_SH_COD" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Reliability</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Process Consequence Analysis" id="Process_Consequence_Analysis" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Reliability Operating Parameter Deviations" id="Reliability_Parameter_Deviations" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Equipment out of service" id="Equipment_Out_Of_Service" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Equipment Returned to Service" id="Equipment_Returned_to_Service" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Total Critical Instrumentation of Failure" id="Critical_Instrumentation_Failure" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Total Equipment Failure" id="Total_Equipment_Failure" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Total Single Point of Failure" id="Total_Single_Point_of_Failure" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Off Shift Maintenance Scheduled or in progress" id="Maintainence_Scheduled_or_InProgress" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Active Permits" id="Active_Permits" reportType="AR_Reliability" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Issues" id="Issues" reportType="AR_Reliability" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Instrumentation out of service</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  id="Instrumentation_Out_of_Service" label="Estimated Return to Service" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  id="Equipment" label="Equipment" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  id="Process_Affected" label="Process Affected" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="PCA Created" id="PCA_Created" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="WO#" id="WO#" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Estimated Return to Service" id="Estimated_Return_to_Service" reportType="AR_RE_InstrumentationOutofService" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange}  label="Maintenance Status" id="Maintenance_Status" reportType="AR_RE_InstrumentationOutofService" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                                
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Equipment returned to operations</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Equipment_Returned_to_Operations" label="Equipment Returned to Operations" reportType="AR_RE_EqpReturnedtoOperations" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Equipment" label="Equipment" reportType="AR_RE_EqpReturnedtoOperations" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Placed_In_Service" label="Placed in Service" reportType="AR_RE_EqpReturnedtoOperations" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="WO#" label="WO#" reportType="AR_RE_EqpReturnedtoOperations" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Single Point of failure</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Single_Point_of_Failure" label="Single Point of Failure" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Equipment" label="Equipment" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Process_Affected" label="Process Affected" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Mitigation_Plan" label="Mitigation Plan" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="WO#" label="WO#" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Estimated_Return_to_Service" label="Estimated Return to Service" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Maintenance_Status" label="Maintenance Status" reportType="AR_RE_SinglePointOfFailure" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} id="Comments" label="Comments" reportType="AR_RE_SinglePointOfFailure" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Streams</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Off_Speciation" label="Off Speciation" reportType="AR_RE_Streams" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="In_Slop" label="In Slop" reportType="AR_RE_Streams" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Finished_Product_Off_Speciation" label="Finished Product Off Speciation" reportType="AR_RE_Streams" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Header>
                                    <Card.Title as="h5">Deliveries</Card.Title>
                                </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Chemical_Loaded" label="Chemical Loaded" reportType="AR_RE_Deliveries" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Chemical_Off-Loaded" label="Chemical Off-Loaded" reportType="AR_RE_Deliveries" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Inventories_Loaded" label="Inventories Loaded" reportType="AR_RE_Deliveries" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} id="Inventories_Off-Loaded" label="Inventories Off-Loaded" reportType="AR_RE_Deliveries" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    {/* <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5">Inventory Tank Levels</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <Row>
                                    <Col md={12}>
                                        <Table responsive hover>
                                            <thead>
                                                <tr>
                                                    <th>Id #</th>
                                                    <th>Target Value</th>
                                                    <th>Achieved</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">1</th>
                                                    <td>2000</td>
                                                    <td>2917</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">2</th>
                                                    <td>2000</td>
                                                    <td>2917</td>
                                                </tr>
                                            </tbody>
                                        </Table>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>  */}
                    {/* <Row>
                    <Col>
                        <Card>
                            <Card.Body>
                                <Button type="submit">Submit</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row> */}
                </Col>
            </Row>
        );
    }
}

export default AreaAReport;
