import React from "react";
import {
    Row,
    Col,
    Card,
    Form,
    Button,
    InputGroup,
    Table,
    FormControl
} from "react-bootstrap";

import Aux from "../../../hoc/_Aux";
import getCurrentDate from "../../helper";
import API from "../../../api";
import YesNoInput from "./YesNoFormInput";
import YesTextInput from "./YesTextInput";

class AreaSupervisorReport extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }


    // * Render form
    render() {
        return (
            <Row>
                <Col>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Header>
                                    <Card.Title as="h5">
                                        Area Supervisor Report
                                </Card.Title>
                                </Card.Header>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Safety Meetings" id="SafetyMeetings" reportType="ASR" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                            <Card.Header>
                                <Card.Title as="h5">Environmental</Card.Title>
                            </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Incidents" id="Incidents" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Near Misses" id="NearMisses" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Draining of Equipment" id="DrainingofEquipment" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Venting" id="Venting" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Venting Flare" id="Venting_Flare" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Venting Atmosphere" id="Venting_Atmosphere" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Deviations" id="Deviations" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Special Monitoring" id="SpecialMonitoring" reportType="ASR" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col>
                            <Card>
                                <Card.Header>
                                    <Card.Title as="h5">MOC</Card.Title>
                                </Card.Header>
                                <Card.Body>
                                    <Row>
                                        <Col sm={12}>
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Number" id="Number" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Title" id="Title" reportType="ASR" />
                                            <YesTextInput {...this.props} handleChange={this.props.handleChange} label="Status" id="Status" reportType="ASR" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} label="Authorize For Use" id="Authorize" reportType="ASR" />
                                            <YesNoInput {...this.props} handleChange={this.props.handleChange} label="Training Notification Complete" id="Training" reportType="ASR" />
                                        </Col>
                                    </Row>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                    {/* <Row>
                    <Col>
                        <Card>
                            <Card.Header>
                                <Card.Title as="h5">Inventory Tank Levels</Card.Title>
                            </Card.Header>
                            <Card.Body>
                                <Row>
                                    <Col md={12}>
                                        <Table responsive hover>
                                            <thead>
                                                <tr>
                                                    <th>Id #</th>
                                                    <th>Target Value</th>
                                                    <th>Achieved</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">1</th>
                                                    <td>2000</td>
                                                    <td>2917</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">2</th>
                                                    <td>2000</td>
                                                    <td>2917</td>
                                                </tr>
                                            </tbody>
                                        </Table>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>  */}
                    {/* <Row>
                    <Col>
                        <Card>
                            <Card.Body>
                                <Button type="submit">Submit</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row> */}
                </Col>
            </Row>
        );
    }
}

export default AreaSupervisorReport;
